import pathlib,subprocess,os,json,shutil
R=pathlib.Path(r'C:/Users/jiangzengming/.codex/worktrees/growth-garden-700/youjia');O=pathlib.Path(__file__).parent
dest=O/'web';dest.mkdir(exist_ok=True)
for rel in ['config/build_identity.json','web/loading.html']:
    backup=O/(pathlib.Path(rel).name+'.before-stamp')
    if not backup.exists():backup.write_bytes((R/rel).read_bytes())
subprocess.run(['python','-X','utf8','tools/stamp_build_identity.py'],cwd=R,check=True)
env=os.environ.copy();env['APPDATA']=str(O/'export-profile')
templates=O/'export-profile/Godot/export_templates/4.7.2.stable'
templates.mkdir(parents=True,exist_ok=True)
for f in pathlib.Path(r'D:/work/outputs/garden-700-20261017/export-profile/Godot/export_templates/4.7.2.stable').glob('web*.zip'):
    shutil.copyfile(f,templates/f.name)
with (O/'export.log').open('wb') as log:
    p=subprocess.run([r'D:/work/tools/godot-4.7.2/Godot_v4.7.2-stable_win64.exe','--headless','--path',str(R),'--export-release','Web',str(dest/'index.html')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
print('export',p.returncode)
assert p.returncode==0
subprocess.run(['python','-X','utf8','test/web_index_buffer_repair_test.py',str(dest/'index.wasm')],cwd=R,check=True)
subprocess.run(['python','-X','utf8','tools/repair_web_index_buffer.py',str(dest/'index.wasm')],cwd=R,check=True)

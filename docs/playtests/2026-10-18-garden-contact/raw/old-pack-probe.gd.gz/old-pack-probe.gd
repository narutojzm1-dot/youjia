extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var identity: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/build_identity.json"))
	var photo: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(OS.get_environment("CONTACT_PHOTO")))
	var codec = load("res://scripts/persistence/save_data_codec.gd")
	var projected: Dictionary = codec.project({"album":["fish_first_catch"],"photo_moments":{"fish_first_catch":photo}})
	var cleaned: Dictionary = projected.photo_moments.get("fish_first_catch",{})
	var serial: Dictionary = JSON.parse_string(JSON.stringify(cleaned))
	var result := {"actual_old_pack":true,"source":identity.sourceCommit,"items_before":photo.items.size(),"items_after":cleaned.get("items",[]).size(),"all_fields_exact":serial==photo}
	var view = load("res://scripts/ui/photo_moment.gd").new()
	view.position = Vector2(120,20)
	view.size = Vector2(680,680)
	root.size = Vector2i(920,720)
	root.add_child(view)
	view.setup(cleaned)
	await process_frame
	await process_frame
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		result.render_saved = root.get_texture().get_image().save_jpg(OS.get_environment("CONTACT_OLD_RENDER"),0.94)==OK
	FileAccess.open(OS.get_environment("CONTACT_PACK_RESULT"),FileAccess.WRITE).store_string(JSON.stringify(result))
	print("ACTUAL_OLD_PACK_PHOTO "+JSON.stringify(result))
	quit(0 if result.all_fields_exact and result.items_before==result.items_after else 1)

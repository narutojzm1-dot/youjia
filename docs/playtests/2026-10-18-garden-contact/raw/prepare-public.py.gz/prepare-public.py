from pathlib import Path
O=Path(__file__).parent
s=(O/'garden-contact-web.cjs').read_text(encoding='utf-8')
sha=(O/'source-commit.txt').read_text().strip()
s=s.replace(f"source='{sha}'","source=process.argv[4],publicURL=process.argv[3]")
s=s.replace("const result={source,","const result={source,actual_public_site:true,")
s=s.replace("await new Promise(r=>server.listen(0,'127.0.0.1',r));url='http://127.0.0.1:'+server.address().port+'/';","url=publicURL;assert(/^https:/.test(url)&&/^[a-f0-9]{40}$/.test(source));")
s=s.replace("new URL('old4/store.mjs',url)","new URL('save-73c41fa/store.mjs',url)")
s=s.replace('server.close();','if(!publicURL)server.close();')
s=s.replace("page.on('pageerror'","page.on('response',r=>{if(r.status()>=400){result.httpFailures??=[];result.httpFailures.push({url:r.url(),status:r.status()});}});page.on('requestfailed',r=>{result.failedRequests??=[];result.failedRequests.push({url:r.url(),error:r.failure()?.errorText});});page.on('pageerror'")
s=s.replace('if(seconds>28&&seconds<46)','if(seconds>28&&seconds<90)')
(O/'garden-contact-public.cjs').write_text(s,encoding='utf-8')
# Keep the unchanged prior writer3 module proof. The audit has its own source/paths.
s=Path(r'D:/work/outputs/garden-700-20261017/audit-public.py').read_text(encoding='utf-8')
(O/'audit-public.py').write_text(s,encoding='utf-8')
print('Prepared direct HTTPS verification; no interception or save clearing')

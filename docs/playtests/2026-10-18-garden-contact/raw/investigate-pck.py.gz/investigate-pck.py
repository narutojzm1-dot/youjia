from pathlib import Path
import json,hashlib,urllib.request,subprocess,gzip,shutil,concurrent.futures
O=Path(__file__).parent;failed=O/'public-failures';failed.mkdir(exist_ok=True)
p=O/'public-files/public/game-6c67e74.pck'
if p.exists() and not (failed/'first-public.pck').exists():shutil.copyfile(p,failed/'first-public.pck')
if (O/'public-audit.log').exists():shutil.copyfile(O/'public-audit.log',failed/'first-audit.log')
G=json.loads(subprocess.check_output(['gh','api','repos/narutojzm1-dot/youjia/git/ref/heads/gh-pages']))['object']['sha']
base='https://narutojzm1-dot.github.io/youjia/';fixed='https://raw.githubusercontent.com/narutojzm1-dot/youjia/'+G+'/'
def get(label,url,headers):
    req=urllib.request.Request(url,headers=headers)
    with urllib.request.urlopen(req,timeout=60) as r:
        b=r.read();h=dict(r.headers);status=r.status
    p=failed/(label+'.pck');p.write_bytes(b)
    v={'label':label,'url':url,'status':status,'headers':h,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'first32_hex':b[:32].hex()}
    if b.startswith(b'\x1f\x8b'):
        raw=gzip.decompress(b);v.update(gzip_decoded_bytes=len(raw),gzip_decoded_sha256=hashlib.sha256(raw).hexdigest());(failed/(label+'-decoded.pck')).write_bytes(raw)
    return v
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
    f1=ex.submit(get,'fixed',fixed+'game-6c67e74.pck',{})
    f2=ex.submit(get,'public-identity',base+'game-6c67e74.pck',{'Accept-Encoding':'identity','Cache-Control':'no-cache','User-Agent':'youjia-release-verification'})
    results=[f1.result(),f2.result()]
(failed/'response-investigation.json').write_text(json.dumps({'gh_pages':G,'downloads':results},indent=2),encoding='utf-8');print(json.dumps(results,indent=2),flush=True)

from pathlib import Path
import json,math
O=Path(__file__).parent;d=json.loads((O/'web-actual/result.json').read_text(encoding='utf-8'))
largest=0.0;numeric=0
def same(a,b,path=''):
    global largest,numeric
    if isinstance(a,(int,float)) and not isinstance(a,bool) and isinstance(b,(int,float)) and not isinstance(b,bool):
        numeric+=1;diff=abs(a-b);largest=max(largest,diff);assert diff<=1e-12,(path,a,b);return
    if isinstance(a,dict):
        assert isinstance(b,dict) and a.keys()==b.keys(),path
        for k in a:same(a[k],b[k],path+'/'+k)
    elif isinstance(a,list):
        assert isinstance(b,list) and len(a)==len(b),path
        for i,(x,y) in enumerate(zip(a,b)):same(x,y,path+'/'+str(i))
    else:assert a==b,(path,a,b)
for key in ['final','reopened']:same(d['initialFixture']['photo_moments'],d[key]['photo_moments'])
result={'pass':True,'actual_recorded_snapshots':True,'compared':['initialFixture','final','reopened'],'keys_arrays_exact':True,'absolute_numeric_tolerance':1e-12,'largest_numeric_difference':largest,'numeric_values_compared':numeric,'reason':'Existing old15fc JSON transform formatting; raw DB4->4 startup rows already compared byte-exact independently'}
(O/'recorded-old-photo-preservation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(result)
p=O/'garden-contact-public.cjs';s=p.read_text(encoding='utf-8')
helper="function samePhoto(a,b){if(typeof a==='number'&&typeof b==='number'){assert(Math.abs(a-b)<=1e-12);return;}if(a&&b&&typeof a==='object'&&typeof b==='object'){assert.deepEqual(Object.keys(a).sort(),Object.keys(b).sort());for(const k of Object.keys(a))samePhoto(a[k],b[k]);return;}assert.deepEqual(a,b);}\n"
s=s.replace('async function save()',helper+'async function save()')
s=s.replace('assert.deepEqual(result.final.meal_ledger,initial.meal_ledger);','assert.deepEqual(result.final.meal_ledger,initial.meal_ledger);samePhoto(result.final.photo_moments,initial.photo_moments);result.actualOld15fcPhotoRetained=true;')
s=s.replace('assert.deepEqual(result.reopened.growth_production,result.final.growth_production);','assert.deepEqual(result.reopened.growth_production,result.final.growth_production);samePhoto(result.reopened.photo_moments,initial.photo_moments);')
p.write_text(s,encoding='utf-8')

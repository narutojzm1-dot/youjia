import pathlib,subprocess,sys,concurrent.futures,json
O=pathlib.Path(__file__).parent
suites=['garden_director','mill_pose','stove_pose','grass_action','photo_moment_save','growth_carried_photo','release_notes','release_notes_pointer_focus']
def run(suite):
    p=subprocess.run([sys.executable,'-X','utf8',str(O/'run-native.py'),suite,'native',f'res://test/{suite}_suite.gd'],capture_output=True,text=True,encoding='utf-8')
    print(p.stdout,flush=True)
    return {'suite':suite,'exit':p.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex: results=list(ex.map(run,suites))
(O/'target-tests.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
sys.exit(0 if all(x['exit']==0 for x in results) else 1)

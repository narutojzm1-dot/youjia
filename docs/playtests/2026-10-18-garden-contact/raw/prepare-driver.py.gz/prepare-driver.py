from pathlib import Path
O=Path(__file__).parent
s=Path(r'D:/work/outputs/garden-700-20261017/garden-web.cjs').read_text(encoding='utf-8')
sha=(O/'source-commit.txt').read_text().strip()
s=s.replace("source='1ab59c1113dd0a1c7d55ca9e34cf3f89ab152814'",f"source='{sha}'")
s=s.replace('old3/','old4/').replace('result.old3Refused','result.current4CanReopen')
s=s.replace('assert.equal(result.rawBefore.version,3)','assert.equal(result.rawBefore.version,4)')
start=s.index(' const beforeOld=await raw();')
end=s.index(" await page.keyboard.press('Escape');await page.waitForTimeout(300)",start)
s=s[:start]+''' const beforeOld=await raw();await page.evaluate(async m=>{const s=await (await import(m)).openStore();s.close();},new URL('old4/store.mjs',url).href);assert.deepEqual(await raw(),beforeOld);result.actualOld4WriterCompatible=true;
'''+s[end:]
s=s.replace('let interrupted=false','let interrupted=false,paused=false')
s=s.replace("if(seconds>31&&seconds<33)await page.screenshot({path:path.join(dir,'03-working.jpg'),type:'jpeg',quality:90});",'''if(seconds>28&&seconds<46)await page.screenshot({path:path.join(dir,'work-'+Math.floor(seconds)+'.jpg'),type:'jpeg',quality:94});
  if(!paused&&seconds>34&&d.yard_garden?.revision!==1){await page.keyboard.press('Escape');await page.waitForTimeout(250);const beforePause=await read();await page.screenshot({path:path.join(dir,'03-paused.jpg'),type:'jpeg',quality:90});await page.waitForTimeout(3500);const afterPause=await read();assert.deepEqual(afterPause.yard_garden,beforePause.yard_garden);assert.deepEqual(afterPause.keepsakes,beforePause.keepsakes);result.pauseNoDebit=true;await page.keyboard.press('Escape');paused=true;}
''')
s=s.replace('assert.equal(result.errors.length,0);','assert(result.pauseNoDebit);assert.equal(result.errors.length,0);')
s=s.replace("const result={source,","const result={source,new_contact_pose:true,existing_writer4:true,")
(O/'garden-contact-web.cjs').write_text(s,encoding='utf-8')
print('Prepared actual continuous ordinary-keyboard candidate driver')

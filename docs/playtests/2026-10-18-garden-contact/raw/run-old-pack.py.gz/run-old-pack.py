import pathlib,subprocess,os,hashlib,json
O=pathlib.Path(__file__).parent
pack=pathlib.Path(r'D:/work/outputs/garden-700-20261017/public-files/public/game-73c41fa.pck')
assert hashlib.sha256(pack.read_bytes()).hexdigest()=='8468bc564e8e9353ddf6a7cd172102340d36b6127424689ba09baa917ac4ea70'
empty=O/'empty-pack-reader';empty.mkdir(exist_ok=True)
env=os.environ.copy();env.update(APPDATA=str(O/'old-pack-profile'),CONTACT_PHOTO=str(O/'garden-contact-photo.json'),CONTACT_PACK_RESULT=str(O/'old-pack-photo-result.json'),CONTACT_OLD_RENDER=str(O/'old-pack-photo.jpg'))
with (O/'old-pack-photo.log').open('wb') as log:
    p=subprocess.run([r'D:/work/tools/godot-4.7.2/Godot_v4.7.2-stable_win64.exe','--path',str(empty),'--main-pack',str(pack),'--script',str(O/'old-pack-probe.gd')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
print((O/'old-pack-photo.log').read_text(encoding='utf-8'))
assert p.returncode==0
d=json.loads((O/'old-pack-photo-result.json').read_text(encoding='utf-8'));assert d['source']=='73c41fa714d4045d48d799c3dff7142dc43df595'
print('Actual complete old public PCK retained all fields and rendered frozen pose')

from pathlib import Path
import shutil,subprocess,json,hashlib,re,datetime
R=Path(r'C:/Users/jiangzengming/.codex/worktrees/growth-garden-700/youjia');O=Path(__file__).parent
dist=O/'web';work=O/'web-versioned';work.mkdir(exist_ok=True)
sha=(O/'source-commit.txt').read_text().strip();entry='game-'+sha[:7]
shutil.copyfile(dist/'index.html',work/'index.html');shutil.copyfile(dist/'index.pck',work/(entry+'.pck'))
for f in dist.glob('*.png'):shutil.copyfile(f,work/f.name)
for stem in ['save','boot']:
    dest=work/(stem+'-'+sha[:7]);dest.mkdir(exist_ok=True)
    for f in (R/'web'/stem).glob('*.mjs'):shutil.copyfile(f,dest/f.name)
html=(work/'index.html').read_text(encoding='utf-8').replace('./web/save/','./save-'+sha[:7]+'/').replace('./web/boot/','./boot-'+sha[:7]+'/')
html=html.replace('data-build=""','data-build="'+entry+'"')
if 'data-build=' not in html:html=html.replace('<html','<html data-build="'+entry+'"',1)
(work/'index.html').write_text(html,encoding='utf-8',newline='\n')
subprocess.run(['python','-X','utf8','tools/stage_web_engine.py',str(dist),str(work),entry],cwd=R,check=True)
m={'schema':'youjia.release/v1','sourceCommit':sha,'entry':entry,'engine':'4.7.2.stable','publishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'engineAssets':json.loads((work/'engine-assets.json').read_text())}
for stem,key in [('save','storageModules'),('boot','loaderModules')]:m[key]={'entry':stem+'-'+sha[:7],'sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((work/(stem+'-'+sha[:7])).glob('*.mjs'))}}
(work/'game-release.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
old=work/'old4';old.mkdir(exist_ok=True)
for f in Path(r'D:/work/outputs/garden-700-20261017/public-files/public/save-73c41fa').glob('*.mjs'):shutil.copyfile(f,old/f.name)
fixture=json.loads(Path(r'D:/work/outputs/garden-700-20261017/fixture-public-old-photo.json').read_text(encoding='utf-8'))
(O/'fixture.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'source':sha,'pck_bytes':(dist/'index.pck').stat().st_size,'pck_sha256':hashlib.sha256((dist/'index.pck').read_bytes()).hexdigest(),'old4_module_files':len(list(old.glob('*.mjs')))},indent=2))

import subprocess, pathlib, os, sys, json
ROOT=pathlib.Path(r'C:/Users/jiangzengming/.codex/worktrees/growth-garden-700/youjia')
OUT=pathlib.Path(__file__).parent
GODOT=r'D:/work/tools/godot-4.7.2/Godot_v4.7.2-stable_win64.exe'
label=sys.argv[1]; mode=sys.argv[2]
profile=OUT/label
profile.mkdir(exist_ok=True)
env=os.environ.copy()
env.update(APPDATA=str(profile),XDG_DATA_HOME=str(profile),YOUJIA_TEST_ISOLATED_DATA=str(profile),YOUJIA_DIRECTOR_CAPTURE=str(OUT),YOUJIA_GARDEN_PHOTO=str(OUT/'garden-contact-photo.json'))
args=[GODOT,'--path',str(ROOT)]
if mode!='gpu': args+=['--headless']
if mode=='import':args+=['--editor','--import','--quit']
else:args+=['--script',sys.argv[3]]
with (OUT/(label+'.log')).open('wb') as log:
    p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    try: rc=p.wait(timeout=180)
    except subprocess.TimeoutExpired: p.kill(); p.wait(); rc=124
text=(OUT/(label+'.log')).read_text(encoding='utf-8',errors='replace')
print(json.dumps({'label':label,'exit':rc,'last':text[-4500:]},ensure_ascii=False))
sys.exit(rc)

from pathlib import Path
import subprocess,json,time,os,urllib.request,datetime,hashlib
O=Path(__file__).parent;R=Path(r'C:/Users/jiangzengming/.codex/worktrees/growth-garden-700/youjia')
M=json.loads((O/'source-merged.json').read_text())['merge']
publish=json.loads((O/'publish-run.json').read_text());assert publish['status']=='completed' and publish['conclusion']=='success'
def gh(*a):return json.loads(subprocess.check_output(['gh',*a],cwd=R))
G=gh('api','repos/narutojzm1-dot/youjia/git/ref/heads/gh-pages')['object']['sha']
last=None;pages=None
for i in range(20):
    runs=gh('run','list','--branch','gh-pages','--limit','15','--json','databaseId,workflowName,headSha,status,conclusion')
    matches=[r for r in runs if r['headSha']==G and r['workflowName']=='pages-build-deployment']
    if matches:
        assert len(matches)==1,matches
        pages=matches[0]
        if pages!=last:print(json.dumps(pages),flush=True);last=pages
        if pages['status']=='completed':assert pages['conclusion']=='success',pages;break
    time.sleep(30)
else:raise RuntimeError('Pages still pending; keep same publication, no redispatch')
for i in range(10):
    try:
        with urllib.request.urlopen(urllib.request.Request('https://narutojzm1-dot.github.io/youjia/game-release.json',headers={'Cache-Control':'no-cache'}),timeout=30) as response:manifest=json.load(response)
        if manifest['sourceCommit']==M:break
        print('Public manifest propagation still old',manifest['sourceCommit'],flush=True)
    except Exception as e:print('Public manifest lookup failure',str(e),flush=True)
    time.sleep(30)
else:raise RuntimeError('Public manifest did not reach expected source; not verified')
def run_log(label,args,env=None,timeout=300):
    with (O/(label+'.log')).open('wb') as log:
        p=subprocess.run(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    if p.returncode:raise RuntimeError(label+' failed: '+(O/(label+'.log')).read_text(encoding='utf-8',errors='replace')[-3500:])
    print(label+' PASS',flush=True)
run_log('public-audit',['python','-X','utf8',str(O/'audit-public.py'),M],timeout=600)
run_log('public-web',[r'C:/Users/jiangzengming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe',str(O/'garden-contact-public.cjs'),'web-public','https://narutojzm1-dot.github.io/youjia/',M],timeout=240)
env=os.environ.copy();env.update(APPDATA=str(O/'public-pack-profile'),CONTACT_PHOTO=str(O/'garden-contact-photo.json'),CONTACT_EXPECTED_PUBLIC=M,CONTACT_PUBLIC_PACK_RESULT=str(O/'public-pack.json'))
pack=O/'public-files/public'/('game-'+M[:7]+'.pck')
run_log('public-pack',[r'D:/work/tools/godot-4.7.2/Godot_v4.7.2-stable_win64.exe','--headless','--path',str(O/'empty-pack-reader'),'--main-pack',str(pack),'--script',str(O/'public-pack-probe.gd')],env=env,timeout=60)
audit=json.loads((O/'public-files/audit.json').read_text());web=json.loads((O/'web-public/result.json').read_text());packed=json.loads((O/'public-pack.json').read_text())
assert audit['pass'] and web['pass'] and packed['pass']
record={'source':M,'publish':publish,'pages':pages,'gh_pages':G,'public_checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_and_fixed_files':len(audit['full_files']),'full_pck_bytes':pack.stat().st_size,'full_pck_sha256':hashlib.sha256(pack.read_bytes()).hexdigest(),'web_seconds':web['completedSeconds'],'reopen_ms':web['reopenMs'],'actual_browser_process_closed':web['actualBrowserProcessClosed'],'public_photo31_old_pack_preserved':packed['photo_fields_exact'],'http_failures':web.get('httpFailures',[]),'request_failures':web.get('failedRequests',[]),'console':web['console'],'pass':True}
(O/'public-verified.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(record,ensure_ascii=False),flush=True)

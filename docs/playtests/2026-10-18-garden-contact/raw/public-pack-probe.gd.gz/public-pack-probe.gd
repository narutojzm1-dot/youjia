extends SceneTree
func _initialize() -> void:
	var identity: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/build_identity.json"))
	var notes: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/release_notes.json"))
	var photo: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(OS.get_environment("CONTACT_PHOTO")))
	var codec = load("res://scripts/persistence/save_data_codec.gd")
	var projected: Dictionary = codec.project({"album":["fish_first_catch"],"photo_moments":{"fish_first_catch":photo}})
	var serial: Dictionary = JSON.parse_string(JSON.stringify(projected.photo_moments.get("fish_first_catch",{})))
	var result := {"actual_public_pack":true,"identity":identity,"title":notes.releases[0].title,"photo_fields_exact":serial==photo,"photo_items":serial.get("items",[]).size(),"new_pose_script_in_pack":ResourceLoader.exists("res://scripts/entities/resident_garden_pose.gd")}
	var ok: bool = identity.sourceCommit==OS.get_environment("CONTACT_EXPECTED_PUBLIC") and result.photo_fields_exact and result.new_pose_script_in_pack and result.title=="蹲下，种一小畦花"
	result.pass = ok
	FileAccess.open(OS.get_environment("CONTACT_PUBLIC_PACK_RESULT"),FileAccess.WRITE).store_string(JSON.stringify(result))
	print("ACTUAL_PUBLIC_CONTACT_PACK "+JSON.stringify(result))
	quit(0 if ok else 1)

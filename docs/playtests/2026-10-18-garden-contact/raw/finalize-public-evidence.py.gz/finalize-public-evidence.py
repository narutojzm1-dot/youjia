from pathlib import Path
import json,hashlib,gzip,shutil,datetime,subprocess
O=Path(__file__).parent;R=Path(r'C:/Users/jiangzengming/.codex/worktrees/growth-garden-700/youjia')
M=json.loads((O/'source-merged.json').read_text())['merge']
audit=json.loads((O/'public-files/audit.json').read_text());web=json.loads((O/'web-public/result.json').read_text());packed=json.loads((O/'public-pack.json').read_text())
assert audit['pass'] and web['pass'] and packed['pass']
publish=json.loads((O/'publish-run.json').read_text())
pages=json.loads(subprocess.check_output(['gh','run','view','39063448844','--json','databaseId,headSha,status,conclusion'],cwd=R))
assert pages['conclusion']=='success' and pages['headSha']==audit['gh_pages_commit']
pack=O/'public-files/public/game-6c67e74.pck'
assert pack.stat().st_size==92455900 and hashlib.sha256(pack.read_bytes()).hexdigest()=='e6781893097eb4e4be3ed3bfb82276dcbed075594f5657112853398af566ad19'
record={'source':M,'publish':publish,'pages':pages,'gh_pages':audit['gh_pages_commit'],'public_checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_and_fixed_files':len(audit['full_files']),'complete_public_and_fixed_downloads':audit['complete_downloads'],'full_pck_bytes':pack.stat().st_size,'full_pck_sha256':hashlib.sha256(pack.read_bytes()).hexdigest(),'web_seconds':web['completedSeconds'],'reopen_ms':web['reopenMs'],'boot_ms':web['bootMs'],'actual_browser_process_closed':web['actualBrowserProcessClosed'],'public_photo31_fields_exact':packed['photo_fields_exact'],'http_failures':web.get('httpFailures',[]),'request_failures':web.get('failedRequests',[]),'console':web['console'],'first_transfer_failed':True,'pass':True}
(O/'public-verified.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
failure={'first_urllib_public_pck':{'file':'first-public.pck','bytes':92441280,'sha256':'d74067aca912108abde942751c95a6c83813aa2db88ec4c5a36eb0aedf8e3265','expected_bytes':92455900,'missing_bytes':14620,'raw_log':'first-audit.log','binary_preserved_locally_and_in_migration':True},'second_fixed_raw_transfer':{'exception_observed_in_tool_result':'IncompleteRead(92450048 bytes read, 5852 more expected)','no_complete_file_or_success_claim':True},'curl_strict_retry_audit':{'download_attempts':len(json.loads((O/'public-files/download-attempts.json').read_text())),'failed_attempts':sum(not x['complete'] for x in json.loads((O/'public-files/download-attempts.json').read_text())),'all_full_pairs_sha_match':True},'cause':'Transport truncation observed; bounded repeat with curl and declared length passed. No claim to diagnose every historic cache/hang issue.'}
(O/'public-failures/failure-and-recovery.json').write_text(json.dumps(failure,indent=2)+'\n',encoding='utf-8')
D=O/'garden-evidence-ready'
def raw(source,relative):
 p=D/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
for name in ['publish-39061852754-success.log','publish-run.json','public-verified.json','public-pack.json','public-pack.log','public-pack-probe.gd','audit-public.py','finish-public-check.py','finalize-public-evidence.py','investigate-pck.py','garden-contact-public.cjs','remote-proof-beef688b.json']:
 raw(O/name,'raw/'+name+'.gz')
for p in (O/'public-files').glob('*'):
 if p.is_file() and p.name!='download.tmp':raw(p,'public-audit/'+p.name+'.gz')
for p in (O/'public-failures').iterdir():
 if p.is_file() and p.suffix!='.pck':raw(p,'public-failures/'+p.name+'.gz')
for p in (O/'web-public').iterdir():
 if p.suffix not in ['.jpg','.json','.webm']:continue
 q=D/'web-public'/p.name;q.parent.mkdir(exist_ok=True)
 if p.suffix=='.json':raw(p,'web-public/'+p.name+'.gz')
 else:shutil.copy2(p,q)
shutil.copy2(O/'public-sowing-excerpt.mp4',D/'public-sowing-excerpt.mp4')
summary='''## 2026-10-18：#700 自主播种专属动作已公开

PR843最终d6b24bdecad301e54a0f0d67bd089bf44a7558b9经完整CI39059712373、Leader审核，合入运行源码6c67e74e719981da46d63de2d953347c6881e833。固定脚位蹲下、扶种/撒种、双手覆土、起身已接入；复用现有批准画层，不更改花种/AP/XP/开花日数、FIFO事务、照片字段或writer版本。原三组花草、近郊农田及其他成长凭据保留。

自动Publish39061852754/Pages39063448844成功；公共与固定gh-pages 187e09279b9acdc7d0103b166af0dece48e19072的32份完整文件/64次下载哈希一致，PCK92455900B/SHA256 e6781893097eb4e4be3ed3bfb82276dcbed075594f5657112853398af566ad19。实际PCK身份/公告/新姿势脚本及31项照片全字段精确保持另核。直接公网合法受控起档后仅普通键鼠，接管与暂停不扣料，90.732秒播种同笔确认；真实关Chrome进程、7426ms重开保持，旧15fc照片原字段及已发布73 writer4可读能力保留。

首次urllib大包读取短14620B；另一次固定源full-read报IncompleteRead短5852B，未当成功。改用严格核对响应长度的curl完整下载后双端一致，失败日志及部分原件仍保存。公网有一条未获URL的404控制台记录，未称零错误或所有旧缓存/停绘制根因已解决。390×844/844×390仅桌面模拟；#700整单、完整三类经验树/一级阈值、实体手机、新灶台食谱仍未完成。一级阈值已询问用户，未答复不自行定案；只等待相关关键步骤。

完整证据见[播种动作归档](docs/playtests/2026-10-18-garden-contact/README.md)（各文档按相对路径定位）；这是临时功能交付，不冒充10月18日23:00日版本节点，后继文档提交不当新运行包。
'''
summary=summary.replace('(docs/playtests/2026-10-18-garden-contact/README.md)','(playtests/2026-10-18-garden-contact/README.md)')
extra=O/'proof-extra-docs'
for name in ['docs/game-design.md','docs/requirements.md','docs/decisions.md','docs/design/growth-phase-2026-10-10.md']:
 old=subprocess.check_output(['git','show',M+':'+name],cwd=R).decode('utf-8')
 first,rest=old.split('\n',1)
 note=summary.replace('(playtests/','(../playtests/') if '/design/' in name else summary
 q=extra/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(first+'\n\n'+note+'\n'+rest,encoding='utf-8',newline='\n')
candidate=(D/'README.md').read_text('utf-8')
(D/'README.md').write_text('''# #700 播种动作：公开交付与原始证据（CODEX-LEAD，2026-10-18）

'''+summary.replace('(playtests/2026-10-18-garden-contact/README.md)','(manifest.json)')+'''
## 公网原件

直接正式站点启动18903ms，播种90.732秒，真实关进程7426ms重开。web-public连续WebM保留全程；public-sowing-excerpt.mp4是同一原录像76–91秒正常速度无音频节选，不作为第二次独立实玩。work-83/88为该次公网实际画面；不是隔离GPU特写换标。初始配置是合法受控测试档，不冒充无物品自然采种链；源PR840的采种/跨日证据仍按原身份保留。

raw/public-verified.json.gz、public-audit/audit.json.gz与download-attempts/response headers包含完整文件清单、64次成对完整下载与另4次入口读取；没有用仅头部/分块样本代替PCK完整哈希。第一次urllib截断/固定源异常与后续严格下载区别记录在public-failures。较大的部分失败PCK保留本机迁移包，仓库仅保留其精确大小、哈希及日志，不冒称这里包含该92MB二进制原件。

## 候选阶段原件（保留当时状态，以下“待公开”只指候选记录时）

'''+candidate,encoding='utf-8',newline='\n')
print(json.dumps(record),flush=True)

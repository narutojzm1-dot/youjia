import pathlib,subprocess,os,json,hashlib,secrets
root=pathlib.Path(__file__).parent; project=root/'source/godot_preview'
godot='C:/Users/Zengm/AppData/Local/Temp/youjia-local-tools/godot/Godot_v4.7.2-stable_win64_console.exe'
template='C:/Users/Zengm/AppData/Local/Temp/youjia-local-tools/web-templates/web_nothreads_release.zip'
env=dict(os.environ);env['APPDATA']=str(root/'owned-appdata');pathlib.Path(env['APPDATA']).mkdir(exist_ok=True)
preset=project/'export_presets.cfg'; original=preset.read_bytes(); text=original.decode().replace('custom_template/release=""',f'custom_template/release="{template}"')
preset.write_text(text,encoding='utf-8');results=[]
try:
 for label in ['a','b']:
  token=secrets.token_hex(16);(project/'build_id.txt').write_text(token+'\n',encoding='utf-8');out=root/('web-'+label);out.mkdir(exist_ok=True)
  cmd=[godot,'--headless','--path',str(project),'--editor','--import','--quit'] if label=='a' else None
  if cmd:
   p=subprocess.run(cmd,env=env,capture_output=True,timeout=180);(root/'import.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.returncode
  p=subprocess.run([godot,'--headless','--path',str(project),'--export-release','Web crop demo 749',str(out/'index.html')],env=env,capture_output=True,timeout=180)
  (root/('export-'+label+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.returncode
  pack=(out/'index.pck').read_bytes();results.append({'label':label,'build_id':token,'bytes':len(pack),'sha256':hashlib.sha256(pack).hexdigest(),'out':str(out)})
  print(json.dumps(results[-1]),flush=True)
finally:
 preset.write_bytes(original)
 (project/'build_id.txt').unlink(missing_ok=True)
(root/'exports.json').write_text(json.dumps({'source':'9d3284ce62b60f0ab709aa8e825ab002615ad275','windows_adaptation':True,'official_template_unmodified':True,'exports':results},indent=2),encoding='utf-8')

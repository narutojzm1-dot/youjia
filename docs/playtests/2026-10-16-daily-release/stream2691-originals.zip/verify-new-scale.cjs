const {chromium}=require('C:/Users/Zengm/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs/promises'),path=require('node:path'),cp=require('node:child_process'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=__dirname, python='C:/Users/Zengm/AppData/Local/Programs/Python/Python310/python.exe';
const result={source:'2691af18978029b1d329ba93c98d73cdb4c753d7',windows_adaptation:true,official_template_unmodified:true,runs:[]};
let browser;const servers=[];
(async()=>{const exports=JSON.parse(await fs.readFile(path.join(root,'exports.json'),'utf8')).exports;
 browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
 for(const item of exports){
  const serverId=crypto.randomBytes(16).toString('hex'),portfile=path.join(root,'port-'+item.label+'.txt');
  const proc=cp.spawn(python,[path.join(root,'source/web_probe_server.py'),'--directory',item.out,'--port-file',portfile,'--server-id',serverId],{windowsHide:true});servers.push(proc);
  let log='';proc.stdout.on('data',b=>log+=b);proc.stderr.on('data',b=>log+=b);
  let port;for(let i=0;i<100;i++){try{port=Number((await fs.readFile(portfile,'utf8')).trim());break;}catch{}await new Promise(r=>setTimeout(r,50));}assert(port);
  const health=await fetch('http://127.0.0.1:'+port+'/__probe_server_id');assert.equal(await health.text(),serverId);
  const page=await browser.newPage({viewport:{width:1672,height:941}}),run={label:item.label,port,serverId,console:[],pageErrors:[]};
  page.on('console',m=>run.console.push({type:m.type(),text:m.text()}));page.on('pageerror',e=>run.pageErrors.push(String(e)));
  const probe=new Promise((yes,no)=>{const t=setTimeout(()=>no(new Error('WEBPROBE timeout')),180000);page.on('console',m=>{if(m.text().startsWith('WEBPROBE ')){clearTimeout(t);try{yes(JSON.parse(m.text().slice(9)));}catch(e){no(e);}}});});
  await page.goto('http://127.0.0.1:'+port+'/index.html?probe=1&probe_nonce='+exports[0].build_id);run.probe=await probe;
  assert.equal(run.probe.build_id,item.build_id);run.same_url_nonce_cannot_spoof_current=item.label==='b'?run.probe.build_id!==exports[0].build_id:true;
  assert(run.same_url_nonce_cannot_spoof_current);assert.equal(proc.exitCode,null);run.server_still_alive=true;
  await page.screenshot({path:path.join(root,'web-'+item.label+'.jpg'),type:'jpeg',quality:82});await page.close();run.server_log=log;result.runs.push(run);
 }
 assert.equal(result.runs.length,1);assert.equal(result.runs[0].probe.scale_subpixel_ok,true);assert.equal(result.runs[0].probe.scale_subpixel.length,2);assert.deepEqual(result.runs[0].probe.scale_subpixel.map(c=>c.scale),[0.75,2]);for(const c of result.runs[0].probe.scale_subpixel){assert.equal(c.ok,true);assert(c.water_changed_mid>0);}assert.equal(result.runs[0].probe.ok,true);assert.equal(result.runs[0].probe.sequence_ok,true);result.pass=true;console.log(JSON.stringify(result.runs.map(r=>({label:r.label,port:r.port,probe:r.probe,pageErrors:r.pageErrors}))));
})().catch(e=>{result.failure=String(e.stack||e);process.exitCode=1;console.error(e);}).finally(async()=>{await browser?.close();for(const p of servers)p.kill();await fs.writeFile(path.join(root,'web-new-scale.json'),JSON.stringify(result,null,2));});

import pathlib,shutil,subprocess,os,json,hashlib
r=pathlib.Path(__file__).parent;prev=pathlib.Path('C:/Users/Zengm/AppData/Local/Temp/youjia-daily-20261016/stream2691')
shutil.copytree(prev/'source',r/'source',dirs_exist_ok=True,ignore=shutil.ignore_patterns('.godot','build_id.txt'))
driver=r/'source/godot_preview/stream_flow_crop_driver.gd';raw=driver.read_bytes();text=raw.decode()
assert '\tout["sequence_ok"] = seq_ok' in text
driver.write_text(text.replace('\tout["sequence_ok"] = seq_ok','\tseq_ok = false # controlled reviewer fault; NOT candidate source\n\tout["sequence_ok"] = seq_ok',1),encoding='utf-8')
script=(prev/'export-own.py').read_text();script=script.replace("'2691af18978029b1d329ba93c98d73cdb4c753d7'","'f8cf2d9c52299efe0ce46703154f5290d3901be4 + controlled sequence=false fixture'")
(r/'export-own.py').write_text(script,encoding='utf-8')
subprocess.run(['C:/Users/Zengm/AppData/Local/Programs/Python/Python310/python.exe','-X','utf8',str(r/'export-own.py')],check=True,timeout=240)
js=(prev/'verify-new-scale.cjs').read_text().replace("source:'2691af18978029b1d329ba93c98d73cdb4c753d7'","source:'f8cf2d9c52299efe0ce46703154f5290d3901be4 + controlled sequence=false fixture'")
js=js.replace('assert.equal(result.runs[0].probe.ok,true);assert.equal(result.runs[0].probe.sequence_ok,true);','assert.equal(result.runs[0].probe.ok,false);assert.equal(result.runs[0].probe.sequence_ok,false);')
(r/'verify-new-scale.cjs').write_text(js,encoding='utf-8')
subprocess.run(['C:/Program Files/nodejs/node.exe',str(r/'verify-new-scale.cjs')],check=True,timeout=240,stdout=(r/'fault-driver.log').open('w',encoding='utf-8'))
probe=json.loads((r/'web-new-scale.json').read_bytes())['runs'][0]['probe'];assert not probe['ok'] and not probe['sequence_ok'] and probe['scale_subpixel_ok'] and all(x['ok'] for x in probe['scale_subpixel'])
log='WEBPROBE '+json.dumps(probe,separators=(',',':'))+'\n';(r/'fault-browser.log').write_text(log,encoding='utf-8')
p=subprocess.run(['C:/Users/Zengm/AppData/Local/Programs/Python/Python310/python.exe','-X','utf8',str(r/'webprobe_verdict.py'),'--log',str(r/'fault-browser.log'),'--build-id',probe['build_id']],capture_output=True)
assert p.returncode==1
result={'candidate':'f8cf2d9c52299efe0ce46703154f5290d3901be4','controlled_driver_mutation':True,'original_driver_sha256':hashlib.sha256(raw).hexdigest(),'mutant_driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'actual_engine_sequence_ok':probe['sequence_ok'],'actual_engine_overall_ok':probe['ok'],'scale_subpixel_ok':probe['scale_subpixel_ok'],'old_substring_would_pass':'"ok":true' in log,'new_parser_exit':p.returncode,'new_parser_stderr':p.stderr.decode(),'not_unmodified_candidate_export':True,'scope':'Windows official template / actual Chrome driver fault injection, not original Linux shell full-chain'}
(r/'fault-verdict.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))

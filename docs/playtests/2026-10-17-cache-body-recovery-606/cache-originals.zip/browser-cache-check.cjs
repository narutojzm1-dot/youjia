const {chromium}=require('C:/Users/Zengm/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const http=require('node:http'),fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
const root=__dirname,results={source:'ba7a48be8b99341eb9c54a54d9cf137e90b0b9a7',controlled_cache_read_fixture:true,actual_chrome:true,gameplay_or_public_release_test:false,runs:[]};let browser;
const server=http.createServer(async(req,res)=>{try{let name=new URL(req.url,'http://local').pathname;
if(name==='/game-ab.pck'){res.setHeader('Content-Type','application/octet-stream');res.end(Buffer.from([0,1,2,3,4,5,6,7]));return;}
if(name==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>Cache body controlled browser check</title>');return;}
res.setHeader('Content-Type','text/javascript');res.end(await fs.readFile(path.join(root,name)));}catch{res.statusCode=404;res.end();}});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
for(const kind of ['idle','short','error','corrupt-prefix','cancel','warm']){
const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(String(e)));await page.goto(origin);
const result=await page.evaluate(async(kind)=>{
const {installAssetRecovery}=await import('/web/boot/download_assets.mjs');const bytes=Uint8Array.from([0,1,2,3,4,5,6,7]);
const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('');
const key=new URL('/game-ab.pck',location.href).href;const store=await caches.open('youjia-startup-assets-v1');
await store.put(key,new Response(bytes,{headers:{'x-youjia-asset-size':'8','x-youjia-asset-sha256':hash}}));
let requests=0,pulls=0,idbAccess=0;const retry=[],failure=[];
const target={location,fetch:async(...args)=>{requests++;return fetch(...args)},caches:{async open(){return {match:async(url)=>{const native=await store.match(url);if(kind==='warm')return native;
return new Response(new ReadableStream({pull(c){if(pulls++===0)c.enqueue(kind==='corrupt-prefix'?Uint8Array.from([255,1,2]):bytes.slice(0,3));else if(kind==='short')c.close();else if(kind==='error')c.error(new Error('controlled cached IO'));}}),{headers:native.headers});},delete:url=>store.delete(url),put:(...args)=>store.put(...args),keys:()=>store.keys()}}}};
Object.defineProperty(target,'indexedDB',{get(){idbAccess++;throw Error('must not access save DB')}});
const restore=installAssetRecovery({fileSizes:{'game-ab.pck':8},fileHashes:{'game-ab.pck':hash}},{target,idleMs:35,maxRetries:1,onRetry:e=>retry.push(e),onError:e=>failure.push(String(e))});
const started=performance.now();let actual,error;const read=(async()=>new Uint8Array(await(await target.fetch('game-ab.pck')).arrayBuffer()))();
if(kind==='cancel')setTimeout(restore,5);
try{actual=Array.from(await Promise.race([read,new Promise((_,no)=>setTimeout(()=>no(Error('test bound exceeded')),1500))]));}catch(e){error=String(e)}restore();
return {kind,actual,error,requests,retry,failure,idbAccess,elapsed_ms:performance.now()-started};
},kind);assert.equal(errors.length,0);assert.equal(result.idbAccess,0);
if(['idle','short','error'].includes(kind)){assert.deepEqual(result.actual,[0,1,2,3,4,5,6,7]);assert.equal(result.requests,1);assert.equal(result.retry.length,1);assert.equal(result.retry[0].offset,3);assert.equal(result.failure.length,0);}
if(kind==='corrupt-prefix'){assert(result.error);assert.equal(result.actual,undefined);assert.equal(result.failure.length,1);assert.match(result.failure[0],/内容校验/);}
if(kind==='cancel'){assert(result.error);assert.equal(result.actual,undefined);assert.equal(result.requests,0);assert.equal(result.failure.length,0);}
if(kind==='warm'){assert.deepEqual(result.actual,[0,1,2,3,4,5,6,7]);assert.equal(result.requests,0);assert.equal(result.retry.length,0);}
results.runs.push(result);await page.close();}
results.pass=true;console.log(JSON.stringify(results));
})().catch(e=>{results.error=String(e.stack||e);process.exitCode=1;console.error(e)}).finally(async()=>{await browser?.close();await new Promise(r=>server.close(r));await fs.writeFile(path.join(root,'browser-cache-check.json'),JSON.stringify(results,null,2));});
